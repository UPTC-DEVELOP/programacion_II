package co.edu.uptc.caso.estudio.persistence;

import java.util.ArrayList;
import java.util.List;
import co.edu.uptc.caso.estudio.model.Venta;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;

import com.google.gson.GsonBuilder;

public class VentaDaoJson implements IVentaDao {

    private final String RUTA_ARCHIVO = "ventas.json";

    @Override
    public void guardarVenta(Venta venta) {
        List<Venta> ventas = obtenerTodas(); 
        ventas.add(venta);                  
        
        // lista actualizada de vuelta al archivo JSON
        try (Writer writer = new FileWriter(RUTA_ARCHIVO)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(ventas, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Venta buscarPorId(String id) {
        List<Venta> ventas = obtenerTodas();
        for (Venta v : ventas) {
            if (v.getId().equals(id)) {
                return v; // Retorna la venta si coincide el ID
            }
        }
        return null; // Si no la encuentra, retorna null
    }

    @Override
    public List<Venta> obtenerTodas() {
        File archivo = new File(RUTA_ARCHIVO);
        if (!archivo.exists()) {
            return new ArrayList<>();
        }
        try (Reader reader = new FileReader(archivo)) {
            Gson gson = new Gson();
            Type tipoLista = new TypeToken<ArrayList<Venta>>(){}.getType();
            List<Venta> ventas = gson.fromJson(reader, tipoLista);
            return ventas != null ? ventas : new ArrayList<>();
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    @Override
    public void eliminarVenta(String id) {
        List<Venta> ventas = obtenerTodas();
        ventas.removeIf(v -> v.getId().equals(id));
        
        try (Writer writer = new FileWriter(RUTA_ARCHIVO)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(ventas, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
      
    }
    
}
        
    