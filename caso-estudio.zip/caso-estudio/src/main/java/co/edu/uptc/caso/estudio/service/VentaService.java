package co.edu.uptc.caso.estudio.service;

import java.util.List;
import co.edu.uptc.caso.estudio.model.Venta;
import co.edu.uptc.caso.estudio.persistence.IVentaDao;

public class VentaService {
    private IVentaDao ventaDao;

    // Constructor que recibe cualquier implementación de IVentaDao
    public VentaService(IVentaDao ventaDao) {
        this.ventaDao = ventaDao;
    }

    public void registrarVenta(Venta venta) {
        ventaDao.guardarVenta(venta);
    }

    public List<Venta> listarVentas() {
        return ventaDao.obtenerTodas();
    }

    public Venta buscarVenta(String id) {
        return ventaDao.buscarPorId(id);
    }

    public void eliminarVenta(String id) {
        ventaDao.eliminarVenta(id);
    }
}
