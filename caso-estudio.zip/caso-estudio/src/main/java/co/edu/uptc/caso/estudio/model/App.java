package co.edu.uptc.caso.estudio.model;


import co.edu.uptc.caso.estudio.persistence.IVentaDao;
import co.edu.uptc.caso.estudio.persistence.VentaDaoJson;
import co.edu.uptc.caso.estudio.service.VentaService;

public class App {
    public static void main(String[] args) {
        // 1. Instanciamos el DAO en formato JSON y la capa de servicio
        IVentaDao daoJson = new VentaDaoJson();
        VentaService servicio = new VentaService(daoJson);

        // 2. Creamos objetos de tipo Venta
        Venta venta1 = new Venta("V001", "2023-11-09", 125000.0, 101);
        Venta venta2 = new Venta("V002", "2023-11-09", 85000.0, 102);

        // 3. Guardamos las ventas
        System.out.println("Guardando ventas en el archivo JSON...");
        servicio.registrarVenta(venta1);
        servicio.registrarVenta(venta2);

        // 4. Consultamos y mostramos las ventas guardadas
        System.out.println("\nLista de ventas registradas:");
        for (Venta v : servicio.listarVentas()) {
            System.out.println("ID: " + v.getId() + " | Fecha: " + v.getFecha() + " | Monto: $" + v.getMontoTotal());
        }
    }
}
