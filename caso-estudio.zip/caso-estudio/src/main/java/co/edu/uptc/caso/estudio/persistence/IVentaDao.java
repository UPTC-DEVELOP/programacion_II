package co.edu.uptc.caso.estudio.persistence;

import java.util.List;
import co.edu.uptc.caso.estudio.model.Venta;

public interface IVentaDao {
    void guardarVenta(Venta venta);
    Venta buscarPorId(String id);
    List<Venta> obtenerTodas();
    void eliminarVenta(String id);
}