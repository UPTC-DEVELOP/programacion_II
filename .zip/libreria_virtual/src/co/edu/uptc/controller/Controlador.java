package co.edu.uptc.controller;

import co.edu.uptc.model.Libro;
import co.edu.uptc.model.TiendaVirtual;

public class Controlador {

    private static TiendaVirtual modelo;

    public Controlador(TiendaVirtual modelo) {
        this.modelo = modelo;
    }

    // ==========================================
    // 1. SOLUCIÓN AL ERROR DE LA LÍNEA 37
    
    
    public void solicitarMostrarLibro() {
        if (((TiendaVirtual) modelo).buscarPorCriterio("").isEmpty()) {
            System.out.println("No hay libros registrados en el catálogo.");
        } else {
            for (Libro libro : modelo.getListaLibro()) {
                System.out.println(libro.getCodigo() + " - " + libro.getTitulo());
            }
        }
    }

    // ==========================================
    // 2. SOLUCIÓN AL ERROR DE LA LÍNEA 71
    // ==========================================
    public static void crearLibro(String isbn, String titulo, String autor, double precio, int stock) {
        Libro nuevo = new Libro();
        Libro libro = new Libro();
		libro.setCodigo("LIB-" + (modelo.buscarPorCriterio("").size() + 1));
        nuevo.setIsbn(isbn);
        nuevo.setTitulo(titulo);
        nuevo.setAutor(autor);
        nuevo.setPrecioBase(precio);
        nuevo.setStock(stock);

        boolean exito = modelo.agregarLibro(nuevo);
        if (exito) {
            System.out.println("¡Libro registrado exitosamente!");
        } else {
            System.out.println("Error: No se pudo agregar el libro.");
        }
    }
}