package co.edu.uptc.model;

/**
 * Representa una línea o ítem dentro del carrito de compras.
 */

public class ItemCarrito {
	
	private Producto producto;
    private int cantidad;

    public ItemCarrito(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * Calcula el subtotal base (precio base * cantidad).
     */
    public double getSubtotalBase() {
        return producto.getPrecioBase() * cantidad;
    }

    /**
     * Calcula el descuento total acumulado para este ítem.
     */
    public double getDescuentoTotal() {
        return producto.calcularDescuento() * cantidad;
    }

    /**
     * Calcula el impuesto total acumulado para este ítem.
     */
    public double getImpuestoTotal() {
        return producto.calcularImpuesto() * cantidad;
    }

    /**
     * Calcula el precio final acumulado para este ítem.
     */
    public double getSubtotalFinal() {
        return producto.getPrecioFinal() * cantidad;
    }

}
