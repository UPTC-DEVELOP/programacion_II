package co.edu.uptc.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Controlador de Lógica de Negocio Principal de la Tienda Virtual.
 * Funciona como punto central de comunicación entre la GUI y los Datos.
 */

public class TiendaVirtual implements IGestionLibro {
	
	private List<Libro> catalogoLibros;
    private CarritoCompras carritoActivo;
	private Libro[] libros;

    public TiendaVirtual() {
        this.catalogoLibros = new ArrayList<>();
        this.carritoActivo = new CarritoCompras();
        cargarDatosPrueba(); // Carga de libros iniciales para pruebas
    }

    
    // IMPLEMENTACIÓN DE IGestionLibros (CRUD)
    

    public boolean agregarLibro(Libro libro) {
        if (libro == null || buscarLibro(libro.getCodigo()) != null) {
            return false; // Libro nulo o ya existente
        }
        return catalogoLibros.add(libro);
    }

    public boolean actualizarLibro(Libro libroEditado) {
        if (libroEditado == null) return false;

        for (int i = 0; i < catalogoLibros.size(); i++) {
            if (((String) catalogoLibros.get(i).getCodigo()).equalsIgnoreCase(libroEditado.getCodigo())) {
                catalogoLibros.set(i, libroEditado);
                return true;
            }
        }
        return false;
    }

   
    public boolean eliminarLibro(String codigoOuIsbn) {
        Libro libro = buscarLibro(codigoOuIsbn);
        if (libro != null) {
            return catalogoLibros.remove(libro);
        }
        return false;
    }

    // --- SOBRECARGA DE MÉTODOS DE BÚSQUEDA ---

 
    public Libro buscarLibro(String codigo) {
        if (codigo == null) {
            return null;
        }
        libros = null;
		for (Libro libro1 :libros) { // o el nombre de tu lista/catálogo
            if (libro1 != null && libro1.getCodigo() != null) {
                if (libro1.getCodigo().equalsIgnoreCase(codigo)) {
                    return libro1;
                }
            }
        }
        return null;
    }
 
    public List<Libro> buscarLibro(String criterio, String tipoBusqueda) {
        List<Libro> resultados = new ArrayList<>();
        String filtro = criterio.toLowerCase();

        for (Libro libro : catalogoLibros) {
            switch (tipoBusqueda.toUpperCase()) {
                case "TITULO":
                    if (libro.getTitulo().toLowerCase().contains(filtro)) resultados.add(libro);
                    break;
                case "AUTOR":
                    if (libro.getAutor().toLowerCase().contains(filtro)) resultados.add(libro);
                    break;
                case "CATEGORIA":
                    if (((String) libro.getCategoria()).toLowerCase().contains(filtro)) resultados.add(libro);
                    break;
                default:
                    if (libro.getTitulo().toLowerCase().contains(filtro) || 
                        libro.getAutor().toLowerCase().contains(filtro)) {
                        resultados.add(libro);
                    }
                    break;
            }
        }
        return resultados;
    }

   
    public List<Libro> listarTodos() {
        return new ArrayList<>(catalogoLibros);
    }

    
    // GESTIÓN DEL CARRITO Y PROCESAMIENTO DE COMPRA
    

    public CarritoCompras getCarritoActivo() {
        return this.carritoActivo; // O el nombre que tenga tu atributo de carrito
    }

    /**
     * Procesa la compra finalizando el carrito actual y descontando el stock del catálogo.
     */
    public boolean procesarCompra() {
        if (carritoActivo.estaVacio()) {
            return false;
        }

        // 1. Verificar stock disponible para todos los productos en el carrito
        for (ItemCarrito item : carritoActivo.getItems()) {
            Libro libroEnCatalogo = buscarLibro(item.getProducto().getCodigo());
            if (libroEnCatalogo == null || libroEnCatalogo.getStock() < item.getCantidad()) {
                return false; // Stock insuficiente en uno de los libros
            }
        }

        // 2. Descontar el stock de los productos comprados
        for (ItemCarrito item : carritoActivo.getItems()) {
            Libro libroEnCatalogo = buscarLibro(item.getProducto().getCodigo());
            libroEnCatalogo.setStock(libroEnCatalogo.getStock() - item.getCantidad());
        }

        // 3. Vaciar el carrito tras la compra exitosa
        carritoActivo.vaciarCarrito();
        return true;
    }

    // ==========================================
    // DATOS DE PRUEBA INICIALES
    // ==========================================

    private void cargarDatosPrueba() {
        Libro l1 = new Libro();
        l1.setCodigo("LIB-001");
        l1.setIsbn("978-0134685991");
        l1.setTitulo("Effective Java");
        l1.setAutor("Joshua Bloch");
        l1.setEditorial("Addison-Wesley");
        l1.setCategoria("Programación");
        l1.setAnioPublicacion(2018);
        l1.setNumeroPaginas(412);
        l1.setFormato("Físico");
        l1.setPrecio(150000.0);
        l1.setStock(15);

        Libro l2 = new Libro();
        l2.setCodigo("LIB-002");
        l2.setIsbn("978-0132350884");
        l2.setTitulo("Clean Code");
        l2.setAutor("Robert C. Martin");
        l2.setEditorial("Prentice Hall");
        l2.setCategoria("Ingeniería de Software");
        l2.setAnioPublicacion(2008);
        l2.setNumeroPaginas(464);
        l2.setFormato("Digital");
        l2.setPrecio(120000.0);
        l2.setStock(20);

        agregarLibro(l1);
        agregarLibro(l2);
    }


	public String getListaLibros() {
		
		return null;
	}


	public String buscarPorCriterio(String string) {
		// TODO Auto-generated method stub
		return null;
	}


	public Libro[] getListaLibro() {
		// TODO Auto-generated method stub
		return null;
	}




}
