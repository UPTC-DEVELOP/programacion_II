package co.edu.uptc.model;

/**
 * Clase abstracta que define la estructura base de un producto en el sistema.
 */

public abstract class Producto {
	
	private String codigo;
    private String titulo;
    private double precioBase;
    private int stock;

    public Producto() {
    }

    public Producto(String codigo, String titulo, double precioBase, int stock) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.precioBase = precioBase;
        this.stock = stock;
    }

    
    // MÉTODOS ABSTRACTOS (POLIMORFISMO)
    

    // Calcula el valor del descuento según el tipo de producto.
   
    public abstract double calcularDescuento();

    /**
     * Calcula el valor del impuesto (IVA) según las reglas del negocio.
     */
    public abstract double calcularImpuesto();

    
    // MÉTODOS CONCRETOS
    

    //**  Calcula el precio final del producto aplicando impuestos y restando descuentos.
    
     
    public double getPrecioFinal() {
        return (precioBase + calcularImpuesto()) - calcularDescuento();
    }

   
    // GETTERS Y SETTERS
    

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Código: " + codigo + " | Título: " + titulo + " | Precio Base: $" + precioBase + " | Stock: " + stock;
    }
    
    //Subclase de Producto que representa un libro en el catálogo.
      
    public class Libro extends Producto {
        private String isbn;
        private String autor;
        private String editorial;
        private String categoria;
        private int anioPublicacion;
        private int numeroPaginas;
        private String formato; // "Físico" o "Digital"

        public Libro() {
            super();
        }

        public Libro(String codigo, String titulo, double precioBase, int stock, String isbn, 
                     String autor, String editorial, String categoria, int anioPublicacion, 
                     int numeroPaginas, String formato) {
            super(codigo, titulo, precioBase, stock);
            this.isbn = isbn;
            this.autor = autor;
            this.editorial = editorial;
            this.categoria = categoria;
            this.anioPublicacion = anioPublicacion;
            this.numeroPaginas = numeroPaginas;
            this.formato = formato;
        }

        
        // IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS
       

        
        public double calcularDescuento() {
            // Los libros digitales tienen un 8% de descuento, los físicos un 5%
            if ("Digital".equalsIgnoreCase(formato)) {
                return getPrecioBase() * 0.08;
            }
            return getPrecioBase() * 0.05;
        }

        
        public double calcularImpuesto() {
            // Aplica el IVA estándar del 19% sobre el precio base
            return getPrecioBase() * 0.19;
        }

        
        // GETTERS Y SETTERS
       

        public String getIsbn() {
            return isbn;
        }

        public void setIsbn(String isbn) {
            this.isbn = isbn;
        }

        public String getAutor() {
            return autor;
        }

        public void setAutor(String autor) {
            this.autor = autor;
        }

        public String getEditorial() {
            return editorial;
        }

        public void setEditorial(String editorial) {
            this.editorial = editorial;
        }

        public String getCategoria() {
            return categoria;
        }

        public void setCategoria(String categoria) {
            this.categoria = categoria;
        }

        public int getAnioPublicacion() {
            return anioPublicacion;
        }

        public void setAnioPublicacion(int anioPublicacion) {
            this.anioPublicacion = anioPublicacion;
        }

        public int getNumeroPaginas() {
            return numeroPaginas;
        }

        public void setNumeroPaginas(int numeroPaginas) {
            this.numeroPaginas = numeroPaginas;
        }

        public String getFormato() {
            return formato;
        }

        public void setFormato(String formato) {
            this.formato = formato;
        }
    }
    

}
