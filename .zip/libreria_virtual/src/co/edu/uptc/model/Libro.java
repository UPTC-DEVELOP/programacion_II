package co.edu.uptc.model;

public class Libro {
	
	// Atributos privados (Encapsulamiento)
    private String isbn;
    private String titulo;
    private String autor;
    private double precio;
    private int stock;

    // Constructor vacío
    public Libro() {
    }

    // Constructor con parámetros
    public Libro(String isbn, String titulo, String autor, double precio, int stock) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.precio = precio;
        this.stock = stock;
    }

    // Getters y Setters
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    // Método toString para facilitar la impresión de datos en la Vista
    
    public String toString() {
        return "Libro [" +
                "ISBN='" + isbn + '\'' +
                ", Título='" + titulo + '\'' +
                ", Autor='" + autor + '\'' +
                ", Precio=" + precio +
                ", Stock=" + stock +
                ']';
    }

	public String getCodigo() {
		return null;
	}

	public Object getCategoria() {
		return null;
	}

	public Object getFormato() {
		return null;
	}

	public void setCodigo(String string) {
		
		
	}

	public void setEditorial(String string) {
		
		
	}

	public void setCategoria(String string) {
		
	}

	public void setAnioPublicacion(int i) {
		
		
	}

	public void setNumeroPaginas(int i) {
		
		
	}

	public void setFormato(String string) {
		
		
	}

	public String getEditorial() {
		
		return null;
	}

	public char[] getAnioPublicacion() {
		
		return null;
	}

	public char[] getNumeroPaginas() {
		
		return null;
	}

	public void setPrecioBase(double d) {
		
		
	}

	public String getPrecioBase() {
		
		return null;
	}

}
