package co.edu.uptc.model.interfaces;

