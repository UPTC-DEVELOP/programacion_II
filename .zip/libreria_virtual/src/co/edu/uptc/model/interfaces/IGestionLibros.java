package co.edu.uptc.model.interfaces;

import java.util.List;


import co.edu.uptc.model.Producto.Libro;

//Interfaz que define el contrato de operaciones de gestión (CRUD) y búsquedas
//para la administración de libros en el sistema.
 
public abstract class IGestionLibros {
	
	//Agrega un nuevo libro al sistema.
      
    abstract boolean agregarLibro(Libro libro);

    // Actualiza la información de un libro existente.
     
    abstract boolean actualizarLibro(Libro libro);

    // Elimina un libro del sistema buscando por su código o ISBN.
     
    abstract boolean eliminarLibro(String codigoOuIsbn);

    //Busca un libro específico por su código exacto o ISBN (Sobrecarga de búsqueda).
     
    abstract Libro buscarLibro(String codigoOuIsbn);

    // Busca libros que coincidan con un criterio y un tipo de filtro especificado (Sobrecarga de búsqueda).
     
    abstract List<Libro> buscarLibro(String criterio, String tipoBusqueda);

    // Devuelve la lista completa de libros registrados.
     
    abstract List<Libro> listarTodos();

}
