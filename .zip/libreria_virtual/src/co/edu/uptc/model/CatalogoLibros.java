package co.edu.uptc.model;

import java.util.ArrayList;
import java.util.List;

public class CatalogoLibros implements IGestionLibros{
	
	private List<Libro> listaLibros;

    public CatalogoLibros() {
        this.listaLibros = new ArrayList<>();
    }

    public boolean agregarLibro(Libro libro) {
        if (libro == null || buscarLibro(libro.getCodigo()) != null) {
            return false; // Libro nulo o ya registrado
        }
        return listaLibros.add(libro);
    }

    
    public boolean actualizarLibro(Libro libroEditado) {
        if (libroEditado == null || libroEditado.getCodigo() == null) {
            return false;
        }
        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getCodigo().equalsIgnoreCase(libroEditado.getCodigo())) {
                listaLibros.set(i, libroEditado);
                return true;
            }
        }
        return false;
    }

 
    public boolean eliminarLibro(String codigo) {
        Libro libro = buscarLibro(codigo);
        if (libro != null) {
            return listaLibros.remove(libro);
        }
        return false;
    }

   
    public List<Libro> buscarPorCriterio(String criterio) {
        List<Libro> resultado = new ArrayList<>();
        if (criterio == null || criterio.trim().isEmpty()) {
            return listaLibros;
        }
        String filtro = criterio.toLowerCase().trim();
        for (Libro libro : listaLibros) {
            if (libro != null && libro.getTitulo() != null && libro.getTitulo().toLowerCase().contains(filtro)) {
                resultado.add(libro);
            }
        }
        return resultado;
    }

    
    // BÚSQUEDAS (SOBRECARGA DE MÉTODOS)
   

    public Libro buscarLibro(String codigoOuIsbn) {
        for (Libro libro : listaLibros) {
            if (libro.getCodigo().equalsIgnoreCase(codigoOuIsbn) || 
                libro.getIsbn().equalsIgnoreCase(codigoOuIsbn)) {
                return libro;
            }
        }
        return null;
    }

   
    public List<Libro> buscarLibro(String criterio, String tipoBusqueda) {
        List<Libro> resultados = new ArrayList<>();
        String filtro = criterio.toLowerCase();

        for (Libro libro : listaLibros) {
            switch (tipoBusqueda.toUpperCase()) {
                case "TITULO":
                    if (libro.getTitulo().toLowerCase().contains(filtro)) resultados.add(libro);
                    break;
                case "AUTOR":
                    if (libro.getAutor().toLowerCase().contains(filtro)) resultados.add(libro);
                    break;
                case "CATEGORIA":
                    if (((String) libro.getCategoria()).toLowerCase().contains(filtro)) resultados.add(libro);
                    break;
                default:
                    if (libro.getTitulo().toLowerCase().contains(filtro) || 
                        libro.getAutor().toLowerCase().contains(filtro)) {
                        resultados.add(libro);
                    }
                    break;
            }
        }
        return resultados;
    }

    public List<Libro> listarTodos() {
        return new ArrayList<>(listaLibros);
    }

    public int getCantidadLibros() {
        return listaLibros.size();
    }

}
