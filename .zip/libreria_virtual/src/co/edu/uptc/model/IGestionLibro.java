package co.edu.uptc.model;

import java.util.List;

public interface IGestionLibro {

	List<Libro> listarTodos();

	List<Libro> buscarLibro(String criterio, String tipoBusqueda);

	Libro buscarLibro(String codigoOuIsbn);

	boolean eliminarLibro(String codigoOuIsbn);

}
