package co.edu.uptc.model;

import java.util.ArrayList;
import java.util.List;

public class tienda implements IGestionLibros {
	
	private List<Libro> listaLibros;
    private CarritoCompras carritoActivo;

    public tienda() {
        this.listaLibros = new ArrayList<>();
        this.carritoActivo = new CarritoCompras();
        cargarDatosPrueba();
    }

    
    // GETTERS Y SETTERS
  

    public CarritoCompras getCarritoActivo() {
        return carritoActivo;
    }

    public void setCarritoActivo(CarritoCompras carritoActivo) {
        this.carritoActivo = carritoActivo;
    }

    public List<Libro> getListaLibros() {
        return listaLibros;
    }

   
    // MÉTODOS DE BÚSQUEDA Y GESTIÓN
  

    public Libro buscarLibro(String codigo) {
        if (codigo == null) {
            return null;
        }
        for (Libro libro : listaLibros) {
            if (libro != null && libro.getCodigo() != null) {
                if (libro.getCodigo().equalsIgnoreCase(codigo)) {
                    return libro;
                }
            }
        }
        return null;
    }

   
    public boolean agregarLibro(Libro libro) {
        if (libro == null || libro.getCodigo() == null) {
            return false;
        }
        if (buscarLibro(libro.getCodigo()) != null) {
            return false; // El libro ya existe en el catálogo
        }
        listaLibros.add(libro);
        return true;
    }

   
    public boolean eliminarLibro(String codigo) {
        Libro libro = buscarLibro(codigo);
        if (libro != null) {
            listaLibros.remove(libro);
            return true;
        }
        return false;
    }

   
    public List<Libro> buscarPorCriterio(String criterio) {
        List<Libro> resultado = new ArrayList<>();
        if (criterio == null || criterio.trim().isEmpty()) {
            return listaLibros;
        }
        String filtro = criterio.toLowerCase().trim();
        for (Libro libro : listaLibros) {
            if (libro != null) {
                boolean coincideCodigo = libro.getCodigo() != null && libro.getCodigo().toLowerCase().contains(filtro);
                boolean coincideTitulo = libro.getTitulo() != null && libro.getTitulo().toLowerCase().contains(filtro);
                boolean coincideAutor = libro.getAutor() != null && libro.getAutor().toLowerCase().contains(filtro);
                boolean coincideCategoria = libro.getCategoria() != null && ((String) libro.getCategoria()).toLowerCase().contains(filtro);

                if (coincideCodigo || coincideTitulo || coincideAutor || coincideCategoria) {
                    resultado.add(libro);
                }
            }
        }
        return resultado;
    }

  
    // PROCESAMIENTO DE VENTAS
  

    public boolean procesarCompra() {
        if (carritoActivo.estaVacio()) {
            return false;
        }

        // 1. Validar que exista suficiente stock en bodega para todos los productos
        for (ItemCarrito item : carritoActivo.getItems()) {
            Libro libroEnStock = buscarLibro(item.getProducto().getCodigo());
            if (libroEnStock == null || libroEnStock.getStock() < item.getCantidad()) {
                return false; // Stock insuficiente
            }
        }

        // 2. Descontar las existencias del catálogo
        for (ItemCarrito item : carritoActivo.getItems()) {
            Libro libroEnStock = buscarLibro(item.getProducto().getCodigo());
            libroEnStock.setStock(libroEnStock.getStock() - item.getCantidad());
        }

        // 3. Vaciar el carrito tras finalizar la compra
        carritoActivo.vaciarCarrito();
        return true;
    }

   
    // CARGA DE DATOS INICIALES
   

    public void cargarDatosPrueba() {
        Libro l1 = new Libro();
        l1.setCodigo("LIB-001");
        l1.setIsbn("978-0307474728");
        l1.setTitulo("Cien Años de Soledad");
        l1.setAutor("Gabriel García Márquez");
        l1.setEditorial("Sudamericana");
        l1.setCategoria("Novela");
        l1.setAnioPublicacion(1967);
        l1.setNumeroPaginas(496);
        l1.setFormato("Físico");
        l1.setPrecioBase(45000.0);
        l1.setStock(15);
        agregarLibro(l1);

        Libro l2 = new Libro();
        l2.setCodigo("LIB-002");
        l2.setIsbn("978-8420658827");
        l2.setTitulo("El Túnel");
        l2.setAutor("Ernesto Sabato");
        l2.setEditorial("Seix Barral");
        l2.setCategoria("Ficción");
        l2.setAnioPublicacion(1948);
        l2.setNumeroPaginas(184);
        l2.setFormato("Digital");
        l2.setPrecioBase(25000.0);
        l2.setStock(30);
        agregarLibro(l2);
    }

}
