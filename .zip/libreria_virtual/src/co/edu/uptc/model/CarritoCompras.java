package co.edu.uptc.model;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * Gestor del carrito de compras activo.
 */

public class CarritoCompras {
	
	private List<ItemCarrito> items;

    public CarritoCompras() {
        this.items = new ArrayList<>();
    }
    
    public List<ItemCarrito> getItems1() {
        return items;
    }

    // Agrega un producto al carrito. Si ya existe, incrementa la cantidad.
     // Valida la disponibilidad en stock.
     
    public boolean agregarProducto(Producto producto, int cantidad) {
        if (producto == null || cantidad <= 0) {
            return false;
        }

        ItemCarrito itemExistente = buscarItem(producto.getCodigo());
        int cantidadTotalDeseada = cantidad + (itemExistente != null ? itemExistente.getCantidad() : 0);

        // Validación de Stock
        if (cantidadTotalDeseada > producto.getStock()) {
            return false; // No hay suficiente stock disponible
        }

        if (itemExistente != null) {
            itemExistente.setCantidad(cantidadTotalDeseada);
        } else {
            items.add(new ItemCarrito(producto, cantidad));
        }

        return true;
    }

    /**
     * Elimina un producto del carrito según su código.
     */
    public boolean eliminarProducto(String codigoProducto) {
        ItemCarrito item = buscarItem(codigoProducto);
        if (item != null) {
            items.remove(item);
            return true;
        }
        return false;
    }

    /**
     * Modifica la cantidad de un producto ya existente en el carrito.
     */
    public boolean actualizarCantidad(String codigoProducto, int nuevaCantidad) {
        if (nuevaCantidad <= 0) {
            return eliminarProducto(codigoProducto);
        }

        ItemCarrito item = buscarItem(codigoProducto);
        if (item != null) {
            if (nuevaCantidad > item.getProducto().getStock()) {
                return false; // Supera el stock disponible
            }
            item.setCantidad(nuevaCantidad);
            return true;
        }
        return false;
    }

    /**
     * Vacía completamente el carrito.
     */
    public void vaciarCarrito() {
        items.clear();
    }

    /**
     * Busca un ítem en el carrito por el código del producto.
     */
    public ItemCarrito buscarItem(String codigoProducto) {
        for (ItemCarrito item : items) {
            if (item.getProducto().getCodigo().equalsIgnoreCase(codigoProducto)) {
                return item;
            }
        }
        return null;
    }

    // --- CÁLCULOS GLOBALES DEL CARRITO ---

    public double calcularSubtotal() {
        double subtotal = 0.0;
        for (ItemCarrito item : items) {
            subtotal += item.getSubtotalBase();
        }
        return subtotal;
    }

    public double calcularDescuentos() {
        double descuentos = 0.0;
        for (ItemCarrito item : items) {
            descuentos += item.getDescuentoTotal();
        }
        return descuentos;
    }

    public double calcularImpuestos() {
        double impuestos = 0.0;
        for (ItemCarrito item : items) {
            impuestos += item.getImpuestoTotal();
        }
        return impuestos;
    }

    public double calcularTotal() {
        return (calcularSubtotal() + calcularImpuestos()) - calcularDescuentos();
    }

    public List<ItemCarrito> getItems() {
        return new ArrayList<>(items); // Retorna una copia para mantener encapsulamiento
    }

    public boolean estaVacio() {
        return items.isEmpty();
    }
    
    
 // Método que genera y retorna la ventana del carrito de compras
    public JFrame VentanaCarrito(JFrame ventanaPadre) {
        // Creamos la ventana de tipo JFrame (o JDialog si prefieres que sea modal)
        JFrame frameCarrito = new JFrame("Carrito de Compras");
        frameCarrito.setSize(400, 300);
        frameCarrito.setLocationRelativeTo(ventanaPadre); // Centrada respecto a la principal
        frameCarrito.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cierra solo esta ventana

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

     // Área de texto o lista para mostrar los libros del carrito
        DefaultListModel<String> modeloLista = new DefaultListModel<>();

        // Recorremos los ítems del carrito activo
        for (ItemCarrito item : tienda.getCarritoActivo().getItems()) {
            String info = item.getProducto().getTitulo() + " | Cantidad: " + item.getCantidad() + " | Subtotal: $" + item.getSubtotalFinal();
            modeloLista.addElement(info);
        }
        
        JList<String> listaLibros = new JList<>(modeloLista);
        JScrollPane scrollPane = new JScrollPane(listaLibros);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Botón de cerrar o comprar
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> frameCarrito.dispose());
        
        JPanel panelSur = new JPanel();
        panelSur.add(btnCerrar);
        panel.add(panelSur, BorderLayout.SOUTH);

        frameCarrito.add(panel);
        return frameCarrito;
        
    }

	public boolean agregarProducto(Libro libro, int cantidad) {
		// TODO Auto-generated method stub
		return false;
	} 

}
