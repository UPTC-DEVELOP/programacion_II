package co.edu.uptc.model;



class ProductoTest {

	
	void test() {
		fail("Not yet implemented");
	}

	private void fail(String string) {
		// TODO Auto-generated method stub
		
	}

}
