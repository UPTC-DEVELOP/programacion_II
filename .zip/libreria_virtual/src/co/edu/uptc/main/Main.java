package co.edu.uptc.main;

import javax.swing.SwingUtilities;
import co.edu.uptc.model.TiendaVirtual;
import co.edu.uptc.view.VentanaPrincipal;

/**
 * Punto de entrada del sistema.
 */

public class Main {

	public static void main(String[] args) {
		// Garantiza que la interfaz Swing se ejecute de forma segura en su hilo dedicado (EDT)
        SwingUtilities.invokeLater(new Runnable() {
           
            public void run() {
                // 1. Instancia el modelo principal
                TiendaVirtual modelo = new TiendaVirtual();
                
                // 2. Instancia la ventana principal pasando el modelo
                VentanaPrincipal ventana = new VentanaPrincipal(modelo);
                
                // 3. Hace visible la GUI
                ventana.setVisible(true);
            }
        });
	}

}
