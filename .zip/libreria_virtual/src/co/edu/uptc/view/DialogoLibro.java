package co.edu.uptc.view;

import co.edu.uptc.model.Libro;

import javax.swing.*;
import java.awt.*;

// Diálogo modal para agregar y editar la información de un Libro.
 
public class DialogoLibro extends JDialog {
	
	private static final long serialVersionUID = 1L;

    private JTextField txtCodigo;
    private JTextField txtIsbn;
    private JTextField txtTitulo;
    private JTextField txtAutor;
    private JTextField txtEditorial;
    private JTextField txtCategoria;
    private JTextField txtAnio;
    private JTextField txtPaginas;
    private JComboBox<String> cbFormato;
    private JTextField txtPrecioBase;
    private JTextField txtStock;

    private boolean guardado = false;
    private Libro libro;

    public DialogoLibro(Frame parent, String tituloVentana, Libro libroEdicion) {
        super(parent, tituloVentana, true);
        this.libro = libroEdicion;
        initComponents();

        if (libroEdicion != null) {
            cargarDatosLibro(libroEdicion);
            txtCodigo.setEditable(false); // Deshabilita la edición del código al modificar
        }

        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel panelForm = new JPanel(new GridLayout(11, 2, 5, 5));
        panelForm.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelForm.add(new JLabel("Código:"));
        txtCodigo = new JTextField();
        panelForm.add(txtCodigo);

        panelForm.add(new JLabel("ISBN:"));
        txtIsbn = new JTextField();
        panelForm.add(txtIsbn);

        panelForm.add(new JLabel("Título:"));
        txtTitulo = new JTextField();
        panelForm.add(txtTitulo);

        panelForm.add(new JLabel("Autor:"));
        txtAutor = new JTextField();
        panelForm.add(txtAutor);

        panelForm.add(new JLabel("Editorial:"));
        txtEditorial = new JTextField();
        panelForm.add(txtEditorial);

        panelForm.add(new JLabel("Categoría:"));
        txtCategoria = new JTextField();
        panelForm.add(txtCategoria);

        panelForm.add(new JLabel("Año Publicación:"));
        txtAnio = new JTextField();
        panelForm.add(txtAnio);

        panelForm.add(new JLabel("Número Páginas:"));
        txtPaginas = new JTextField();
        panelForm.add(txtPaginas);

        panelForm.add(new JLabel("Formato:"));
        cbFormato = new JComboBox<>(new String[]{"Físico", "Digital"});
        panelForm.add(cbFormato);

        panelForm.add(new JLabel("Precio Base ($):"));
        txtPrecioBase = new JTextField();
        panelForm.add(txtPrecioBase);

        panelForm.add(new JLabel("Stock Inicial:"));
        txtStock = new JTextField();
        panelForm.add(txtStock);

        add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnGuardar = new JButton("Guardar");
        JButton btnCancelar = new JButton("Cancelar");

        btnGuardar.addActionListener(e -> accionGuardar());
        btnCancelar.addActionListener(e -> dispose());

        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);

        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarDatosLibro(Libro l) {
        txtCodigo.setText(l.getCodigo());
        txtIsbn.setText(l.getIsbn());
        txtTitulo.setText(l.getTitulo());
        txtAutor.setText(l.getAutor());
        txtEditorial.setText(l.getEditorial());
        txtCategoria.setText((String) l.getCategoria());
        txtAnio.setText(String.valueOf(l.getAnioPublicacion()));
        txtPaginas.setText(String.valueOf(l.getNumeroPaginas()));
        cbFormato.setSelectedItem(l.getFormato());
        txtPrecioBase.setText(String.valueOf(l.getPrecio()));
        txtStock.setText(String.valueOf(l.getStock()));
    }

    private void accionGuardar() {
        try {
            if (txtCodigo.getText().trim().isEmpty() || txtTitulo.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "El Código y el Título son campos obligatorios.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (libro == null) {
                libro = new Libro();
            }

            libro.setCodigo(txtCodigo.getText().trim());
            libro.setIsbn(txtIsbn.getText().trim());
            libro.setTitulo(txtTitulo.getText().trim());
            libro.setAutor(txtAutor.getText().trim());
            libro.setEditorial(txtEditorial.getText().trim());
            libro.setCategoria(txtCategoria.getText().trim());
            libro.setAnioPublicacion(Integer.parseInt(txtAnio.getText().trim()));
            libro.setNumeroPaginas(Integer.parseInt(txtPaginas.getText().trim()));
            libro.setFormato((String) cbFormato.getSelectedItem());
            libro.setPrecio(Double.parseDouble(txtPrecioBase.getText().trim()));
            libro.setStock(Integer.parseInt(txtStock.getText().trim()));

            guardado = true;
            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese números válidos para Año, Páginas, Precio y Stock.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isGuardado() {
        return guardado;
    }

    public Libro getLibro() {
        return libro;
    }

}
