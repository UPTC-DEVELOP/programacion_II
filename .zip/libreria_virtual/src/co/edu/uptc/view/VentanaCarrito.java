package co.edu.uptc.view;

import co.edu.uptc.model.ItemCarrito;
import co.edu.uptc.model.TiendaVirtual;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;


// Ventana modal para visualizar los productos agregados al carrito,
  //modificar cantidades, eliminar ítems y procesar la compra final.
 

public class VentanaCarrito extends JDialog {
	
	private static final long serialVersionUID = 1L;

    private TiendaVirtual tienda;

    // Componentes de la Interfaz
    private JTable tablaItems;
    private DefaultTableModel modeloTabla;
    private JLabel lblSubtotal;
    private JLabel lblDescuentos;
    private JLabel lblImpuestos;
    private JLabel lblTotal;

    public VentanaCarrito(Frame parent, TiendaVirtual tienda) {
        super(parent, "Carrito de Compras", true);
        this.tienda = tienda;
        initComponents();
        cargarDatos();
        setSize(750, 480);
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));


        // TABLA DE PRODUCTOS EN EL CARRITO
        
        String[] columnas = {"Código", "Título", "Cantidad", "Precio Unit.", "Descuento", "Impuesto (IVA)", "Subtotal"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Celdas no editables directamente
            }
        };

        tablaItems = new JTable(modeloTabla);
        tablaItems.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollTabla = new JScrollPane(tablaItems);
        scrollTabla.setBorder(BorderFactory.createTitledBorder(" Productos Seleccionados "));

        add(scrollTabla, BorderLayout.CENTER);

      
        // PANEL INFERIOR: Totales y Acciones
       
        JPanel panelInferior = new JPanel(new BorderLayout());

        // Subpanel de Totales Financieros
        JPanel panelTotales = new JPanel(new GridLayout(4, 2, 5, 5));
        panelTotales.setBorder(BorderFactory.createTitledBorder(" Resumen Financiero "));

        lblSubtotal = new JLabel("$0.00");
        lblDescuentos = new JLabel("$0.00");
        lblImpuestos = new JLabel("$0.00");
        lblTotal = new JLabel("$0.00");

        // Formato con negrita para la etiqueta final de Total
        Font fontBold = new Font("SansSerif", Font.BOLD, 13);
        JLabel lblTotalTitulo = new JLabel("TOTAL A PAGAR:");
        lblTotalTitulo.setFont(fontBold);
        lblTotal.setFont(fontBold);

        panelTotales.add(new JLabel("Subtotal Base:"));
        panelTotales.add(lblSubtotal);
        panelTotales.add(new JLabel("Descuentos Aplicados (-):"));
        panelTotales.add(lblDescuentos);
        panelTotales.add(new JLabel("Impuestos (IVA 19%) (+):"));
        panelTotales.add(lblImpuestos);
        panelTotales.add(lblTotalTitulo);
        panelTotales.add(lblTotal);

        // Subpanel de Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JButton btnModificar = new JButton("Modificar Cantidad");
        JButton btnEliminar = new JButton("Eliminar Producto");
        JButton btnVaciar = new JButton("Vaciar Carrito");
        JButton btnComprar = new JButton("Finalizar Compra");

        btnModificar.addActionListener(e -> accionModificarCantidad());
        btnEliminar.addActionListener(e -> accionEliminarItem());
        btnVaciar.addActionListener(e -> accionVaciarCarrito());
        btnComprar.addActionListener(e -> accionProcesarCompra());

        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnVaciar);
        panelBotones.add(btnComprar);

        panelInferior.add(panelTotales, BorderLayout.NORTH);
        panelInferior.add(panelBotones, BorderLayout.SOUTH);

        add(panelInferior, BorderLayout.SOUTH);
    }

    
    // MÉTODOS DE ACTUALIZACIÓN Y LÓGICA
    

    private void cargarDatos() {
        modeloTabla.setRowCount(0); // Limpiar filas previas

        // Recorre la lista encapsulada dentro de CarritoCompras
        for (ItemCarrito item : tienda.getCarritoActivo().getItems()) {
            Object[] fila = {
                item.getProducto().getCodigo(),
                item.getProducto().getTitulo(),
                item.getCantidad(),
                "$" + String.format("%.2f", item.getProducto().getPrecioBase()),
                "$" + String.format("%.2f", item.getDescuentoTotal()),
                "$" + String.format("%.2f", item.getImpuestoTotal()),
                "$" + String.format("%.2f", item.getSubtotalFinal())
            };
            modeloTabla.addRow(fila);
        }

        // Actualización de los totales en las etiquetas
        lblSubtotal.setText("$" + String.format("%.2f", tienda.getCarritoActivo().calcularSubtotal()));
        lblDescuentos.setText("$" + String.format("%.2f", tienda.getCarritoActivo().calcularDescuentos()));
        lblImpuestos.setText("$" + String.format("%.2f", tienda.getCarritoActivo().calcularImpuestos()));
        lblTotal.setText("$" + String.format("%.2f", tienda.getCarritoActivo().calcularTotal()));
    }

    private void accionModificarCantidad() {
        int fila = tablaItems.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un producto de la lista.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String codigo = (String) modeloTabla.getValueAt(fila, 0);
        String cantidadActual = String.valueOf(modeloTabla.getValueAt(fila, 2));

        String nuevaCantStr = JOptionPane.showInputDialog(this, "Ingrese la nueva cantidad:", cantidadActual);

        if (nuevaCantStr != null && !nuevaCantStr.trim().isEmpty()) {
            try {
                int nuevaCantidad = Integer.parseInt(nuevaCantStr);
                boolean exito = tienda.getCarritoActivo().actualizarCantidad(codigo, nuevaCantidad);
                if (exito) {
                    cargarDatos();
                } else {
                    JOptionPane.showMessageDialog(this, "La cantidad no es válida o supera el stock disponible en bodega.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Ingrese un número entero válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void accionEliminarItem() {
        int fila = tablaItems.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para eliminar del carrito.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String codigo = (String) modeloTabla.getValueAt(fila, 0);
        tienda.getCarritoActivo().eliminarProducto(codigo);
        cargarDatos();
    }

    private void accionVaciarCarrito() {
        if (tienda.getCarritoActivo().estaVacio()) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "¿Desea eliminar todos los productos del carrito?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            tienda.getCarritoActivo().vaciarCarrito();
            cargarDatos();
        }
    }

    private void accionProcesarCompra() {
        if (tienda.getCarritoActivo().estaVacio()) {
            JOptionPane.showMessageDialog(this, "El carrito está vacío. Agregue productos antes de comprar.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, 
                "¿Desea confirmar y procesar el pago de la compra por $" + String.format("%.2f", tienda.getCarritoActivo().calcularTotal()) + "?", 
                "Confirmar Compra", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean exito = tienda.procesarCompra();
            if (exito) {
                JOptionPane.showMessageDialog(this, "¡Compra procesada con éxito!\nEl stock del catálogo ha sido actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Cierra la ventana tras finalizar
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo procesar la compra debido a falta de stock de algún producto.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}
