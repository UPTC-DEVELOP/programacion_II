package co.edu.uptc.view;

import co.edu.uptc.controller.Controlador;
import co.edu.uptc.controller.Controler; // El controlador que necesita importar la vista
import co.edu.uptc.model.Libro;         // Para recibir objetos del modelo

import java.util.Scanner;

public class View {
	
	private Controler controller; // La vista conoce al controlador para enviarle acciones del usuario
    private Scanner scanner;

    // Constructor que recibe el controlador (Inyección de dependencias)
    public View(Controler controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    // Método principal para mostrar el menú al usuario
    public void mostrarMenu() {
        int opcion = 0;
        do {
            System.out.println("\n==================================");
            System.out.println("       SISTEMA DE GESTIÓN DE LIBROS  ");
            System.out.println("==================================");
            System.out.println("1. Mostrar información del libro");
            System.out.println("2. Registrar un nuevo libro");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer de entrada

            switch (opcion) {
                case 1:
                    // Le pide al controlador que ejecute la acción de mostrar
                    controller.solicitarMostrarLibro();
                    break;
                case 2:
                    pedirDatosNuevoLibro();
                    break;
                case 3:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 3);
    }

    // Método para capturar datos desde la consola y enviárselos al controlador
    public void pedirDatosNuevoLibro() {
        System.out.println("\n--- REGISTRAR NUEVO LIBRO ---");
        System.out.print("Ingrese ISBN: ");
        String isbn = scanner.nextLine();
        
        System.out.print("Ingrese Título: ");
        String titulo = scanner.nextLine();
        
        System.out.print("Ingrese Autor: ");
        String autor = scanner.nextLine();
        
        System.out.print("Ingrese Precio: ");
        double precio = scanner.nextDouble();
        
        System.out.print("Ingrese Stock: ");
        int stock = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer

        // Envia los datos recolectados al controlador para que él cree el modelo
        Controlador.crearLibro(isbn, titulo, autor, precio, stock);
    }

    // Método para imprimir un libro en pantalla
    public void mostrarLibro(Libro libro) {
        if (libro == null) {
            System.out.println("\n[Aviso] No hay ningún libro registrado todavía.");
            return;
        }
        
        System.out.println("\n==================================");
        System.out.println("       INFORMACIÓN DEL LIBRO      ");
        System.out.println("==================================");
        System.out.println("ISBN   : " + libro.getIsbn());
        System.out.println("Título : " + libro.getTitulo());
        System.out.println("Autor  : " + libro.getAutor());
        System.out.println("Precio : $" + libro.getPrecio());
        System.out.println("Stock  : " + libro.getStock() + " unidades");
        
    }

    // Método genérico para mostrar mensajes en la consola
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

}
