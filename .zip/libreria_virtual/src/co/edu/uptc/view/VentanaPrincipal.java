package co.edu.uptc.view;

import co.edu.uptc.model.ItemCarrito;
import co.edu.uptc.model.Libro;
import co.edu.uptc.model.TiendaVirtual;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

// Ventana Principal de la aplicación Swing.
 // Muestra el catálogo de libros y coordina las acciones del usuario.
 

public class VentanaPrincipal extends JFrame {
	
	
	private static final long serialVersionUID = 1L;

	private TiendaVirtual tienda;

    // Componentes de la Interfaz
    private JTable tablaLibros;
    private DefaultTableModel modeloTabla;
    private JTextField txtBuscar;
    private JComboBox<String> cbFiltro;
    private JLabel lblEstadoCarrito;

    public VentanaPrincipal(TiendaVirtual tienda) {
        this.tienda = tienda;
        initComponents();
        cargarDatosTabla(tienda.listarTodos());
    }

    private void initComponents() {
        setTitle("Sistema de Gestión de Tienda Virtual de Libros - UPTC");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setLayout(new BorderLayout(10, 10));

        
        // PANEL SUPERIOR: Búsqueda y Filtros
        
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panelSuperior.setBorder(BorderFactory.createTitledBorder(" Búsqueda de Libros "));

        panelSuperior.add(new JLabel("Buscar:"));
        txtBuscar = new JTextField(20);
        panelSuperior.add(txtBuscar);

        panelSuperior.add(new JLabel("Filtrar por:"));
        cbFiltro = new JComboBox<>(new String[]{"TODOS", "TITULO", "AUTOR", "CATEGORIA"});
        panelSuperior.add(cbFiltro);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> accionBuscar());
        panelSuperior.add(btnBuscar);

        JButton btnRestaurar = new JButton("Ver Todos");
        btnRestaurar.addActionListener(e -> {
            txtBuscar.setText("");
            cargarDatosTabla(tienda.listarTodos());
        });
        panelSuperior.add(btnRestaurar);

        add(panelSuperior, BorderLayout.NORTH);

        
        // PANEL CENTRAL: Tabla de Libros
       
        String[] columnas = {"Código", "ISBN", "Título", "Autor", "Categoría", "Formato", "Precio Base", "Stock"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            private static final long serialVersionUID = 1L; // <--- AGREGAR ESTA LÍNEA

            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hacer las celdas no editables directamente
            }
        };

        tablaLibros = new JTable(modeloTabla);
        tablaLibros.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollTabla = new JScrollPane(tablaLibros);
        scrollTabla.setBorder(BorderFactory.createTitledBorder(" Catálogo de Libros "));

        add(scrollTabla, BorderLayout.CENTER);

       
        // PANEL INFERIOR: Botones de Acción
   
        JPanel panelInferior = new JPanel(new BorderLayout());

        JPanel panelBotonesCRUD = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton btnAgregar = new JButton("Agregar Libro");
        JButton btnEditar = new JButton("Editar Selección");
        JButton btnEliminar = new JButton("Eliminar Selección");

        btnAgregar.addActionListener(e -> accionAgregarLibro());
        btnEditar.addActionListener(e -> accionEditarLibro());
        btnEliminar.addActionListener(e -> accionEliminarLibro());

        panelBotonesCRUD.add(btnAgregar);
        panelBotonesCRUD.add(btnEditar);
        panelBotonesCRUD.add(btnEliminar);

        JPanel panelBotonesCarrito = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JButton btnAgregarAlCarrito = new JButton("Añadir al Carrito");
        JButton btnVerCarrito = new JButton("Ver Carrito de Compras");
        lblEstadoCarrito = new JLabel("Ítems en Carrito: 0");

        btnAgregarAlCarrito.addActionListener(e -> accionAgregarAlCarrito());
        btnVerCarrito.addActionListener(e -> accionVerCarrito());

        panelBotonesCarrito.add(lblEstadoCarrito);
        panelBotonesCarrito.add(btnAgregarAlCarrito);
        panelBotonesCarrito.add(btnVerCarrito);

        panelInferior.add(panelBotonesCRUD, BorderLayout.WEST);
        panelInferior.add(panelBotonesCarrito, BorderLayout.EAST);

        add(panelInferior, BorderLayout.SOUTH);
    }

   
    // MÉTODOS Y ACCIONES DE LA GUI
    

    public void cargarDatosTabla(List<Libro> lista) {
        modeloTabla.setRowCount(0); // Limpiar tabla
        for (Libro libro : lista) {
            Object[] fila = {
                libro.getCodigo(),
                libro.getIsbn(),
                libro.getTitulo(),
                libro.getAutor(),
                libro.getCategoria(),
                libro.getFormato(),
                "$" + String.format("%.2f", libro.getPrecio()),
                libro.getStock()
            };
            modeloTabla.addRow(fila);
        }
        actualizarResumenCarrito();
    }

    private void accionBuscar() {
        String texto = txtBuscar.getText().trim();
        String filtro = (String) cbFiltro.getSelectedItem();

        if (texto.isEmpty() || "TODOS".equalsIgnoreCase(filtro)) {
            cargarDatosTabla(tienda.listarTodos());
        } else {
            List<Libro> resultados = tienda.buscarLibro(texto, filtro);
            cargarDatosTabla(resultados);
        }
    }

    private void accionAgregarLibro() {
    	
        // Muestra el diálogo en modo creación
    	
    	DialogoLibro dialogo = new DialogoLibro(this, "Agregar Nuevo Libro", null);
        dialogo.setVisible(true);

        if (dialogo.isGuardado()) {
            Libro nuevoLibro = dialogo.getLibro();
            boolean exito = tienda.agregarLibro(nuevoLibro);
            if (exito) {
                JOptionPane.showMessageDialog(this, "Libro agregado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(tienda.listarTodos());
            } else {
                JOptionPane.showMessageDialog(this, "El código o ISBN ya existe en el catálogo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void accionEditarLibro() {
        int fila = tablaLibros.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un libro de la tabla.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String codigo = (String) modeloTabla.getValueAt(fila, 0);
        Libro libroExistente = tienda.buscarLibro(codigo);

        if (libroExistente != null) {
            DialogoLibro dialogo = new DialogoLibro(this, "Editar Libro", libroExistente);
            dialogo.setVisible(true);

            if (dialogo.isGuardado()) {
                tienda.actualizarLibro(dialogo.getLibro());
                JOptionPane.showMessageDialog(this, "Libro actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(tienda.listarTodos());
            }
        }
    }

    private void accionEliminarLibro() {
        int fila = tablaLibros.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un libro para eliminar.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String codigo = (String) modeloTabla.getValueAt(fila, 0);
        int confirm = JOptionPane.showConfirmDialog(this, 
                "¿Está seguro de eliminar el libro con código " + codigo + "?", 
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (tienda.eliminarLibro(codigo)) {
                JOptionPane.showMessageDialog(this, "Libro eliminado correctamente.");
                cargarDatosTabla(tienda.listarTodos());
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar el libro.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void accionAgregarAlCarrito() {
        int fila = tablaLibros.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un libro para añadir al carrito.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String codigo = (String) modeloTabla.getValueAt(fila, 0);
        Libro libro = tienda.buscarLibro(codigo);

        if (libro != null) {
            String cantStr = JOptionPane.showInputDialog(this, "Ingrese la cantidad para '" + libro.getTitulo() + "':", "1");
            if (cantStr != null && !cantStr.trim().isEmpty()) {
                try {
                    int cantidad = Integer.parseInt(cantStr);
                    if (tienda.getCarritoActivo().agregarProducto(libro, cantidad)) {
                        JOptionPane.showMessageDialog(this, "Producto añadido al carrito.");
                        actualizarResumenCarrito();
                    } else {
                        JOptionPane.showMessageDialog(this, "No hay suficiente stock disponible.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void accionVerCarrito() {
        VentanaCarrito ventanaCarrito = new VentanaCarrito(this, tienda);
        ventanaCarrito.setVisible(true);
        cargarDatosTabla(tienda.listarTodos()); // Refrescar por si cambió el stock tras comprar
    }

    private void actualizarResumenCarrito() {
        int numItems = 0;
        for (ItemCarrito item : tienda.getCarritoActivo().getItems()) {
            numItems += item.getCantidad();
        }
        lblEstadoCarrito.setText("Ítems en Carrito: " + numItems);
    }

	
	public String toString() {
		return "VentanaPrincipal [tienda=" + tienda + ", tablaLibros=" + tablaLibros + ", modeloTabla=" + modeloTabla
				+ ", txtBuscar=" + txtBuscar + ", cbFiltro=" + cbFiltro + ", lblEstadoCarrito=" + lblEstadoCarrito
				+ "]";
	}
  
}
