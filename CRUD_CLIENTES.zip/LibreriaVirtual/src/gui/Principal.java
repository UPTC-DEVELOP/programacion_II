package gui;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginFrame ventana=new LoginFrame();
		ventana.setVisible(true);
	}

}
