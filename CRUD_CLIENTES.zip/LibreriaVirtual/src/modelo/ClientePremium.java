package modelo;

public class ClientePremium extends Cliente{
		// TODO Auto-generated constructor stub
	public ClientePremium(String tipoDocumento, int numeroDocumento, String nombre, String apellido, String correo, String telefono, 
			String contrasenia) {
		
		super(tipoDocumento, numeroDocumento, nombre, apellido, correo, telefono, contrasenia);
	}

}
